package com.fit.microservices.order.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "cart_item")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class CartItem {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(nullable = false)
    private String skuCode;
    private Long productId;
    private String name;
    private Double price;
    private String image;
    private Integer quantity;
    private String size;
    private String color;
    @ManyToOne
    @JoinColumn(name = "cart_id")
    private Cart cart;
}
