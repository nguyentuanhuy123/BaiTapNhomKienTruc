import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import Navbar from '../components/common/Navbar';
import Footer from '../components/common/Footer';
import paymentApi from '../api/paymentApi';
import userApi from '../api/userApi';

// ── Mock cart data (dùng trực tiếp, không lấy từ localStorage) ──────────────
const MOCK_CART_ITEMS = [
  {
    id: 1,
    name: 'Velocity Pro 1.0',
    size: '10.5',
    color: 'Neon Pulse',
    qty: 1,
    price: 180000.0,
    image:
      'https://lh3.googleusercontent.com/aida-public/AB6AXuDlNG2P_20pGAAH4lD1LeB5XUPjnnrFc1Iqelb0yK_m5pU8LBE-r1o2Qc0s98A3ibTFLgTBWkOL_Of5_oOH0uULbeky0x39_KUNX_WWNODTJMDKHAAG_xht_x1U0gWH71RRXbW_ZtO1ozzj1yI-3cDWy7ha4kOLfSxqzcFYN7BgdKbZ3lfnDHt2k0E7f0EimKNABOUGiiHM7MyaiARflxSGkXj5a0rOM8LI-ylmoHgcPxKHEJvRV5XyWWxtRcZzNNk7Ff5qopsRjeM',
  },
  {
    id: 2,
    name: 'StepTech Socks',
    size: 'L',
    color: 'Arctic White',
    qty: 2,
    price: 240000.0,
    image:
      'https://lh3.googleusercontent.com/aida-public/AB6AXuAz8dC1bhFHEAQ2mtNFLQZxqJmpjz1uJPQ9tyYXoNc7rwV15o7-D75288YdtAAKKdypNXvg0TQPkXwx4KrxVYtGLy1Y8QFAJn59CzNNj1yI-3cDWy7ha4kOLfSxqzcFYN7BgdKbZ3lfnDHt2k0E7f0EimKNABOUGiiHM7MyaiARflxSGkXj5a0rOM8LI-ylmoHgcPxKHEJvRV5XyWWxtRcZzNNk7Ff5qopsRjeM',
  },
];

const subtotal = MOCK_CART_ITEMS.reduce((s, i) => s + i.price * i.qty, 0);
const tax      = +(subtotal * 0.08).toFixed(2);
const total    = +(subtotal + tax).toFixed(2);

// ─────────────────────────────────────────────────────────────────────────────

const CheckoutPage = () => {
  const [step, setStep]                   = useState(1);
  const [paymentMethod, setPaymentMethod] = useState('cod');
  const [shippingMethod, setShippingMethod] = useState('standard');
  const [loading, setLoading]             = useState(false);
  const [error, setError]                 = useState('');
  const [orderPlaced, setOrderPlaced]     = useState(false);
  const [placedOrderId, setPlacedOrderId] = useState(null);
  const [userData, setUserData]           = useState(null);

  // Shipping form state
  const [form, setForm] = useState({
    firstName: '',
    lastName: '',
    address: '',
    city: '',
  });

  // Fetch user profile và tự điền thông tin vào form
  useEffect(() => {
    const fetchUser = async () => {
      try {
        const data = await userApi.getCurrentUser();
        setUserData(data);
        if (data) {
          // Tách fullName thành firstName + lastName
          const parts = (data.fullName || '').trim().split(' ');
          const lastName  = parts.length > 1 ? parts.slice(-1)[0] : '';
          const firstName = parts.length > 1 ? parts.slice(0, -1).join(' ') : parts[0] || '';

          // Tách address thành street + city (nếu có dấu phẩy)
          const addressParts = (data.address || '').split(',');
          const street = addressParts[0]?.trim() || '';
          const city   = addressParts.slice(1).join(',').trim() || '';

          setForm({ firstName, lastName, address: street, city });
        }
      } catch (err) {
        console.error('Không thể tải thông tin người dùng', err);
      }
    };
    fetchUser();
  }, []);

  const handleFormChange = (e) =>
    setForm((f) => ({ ...f, [e.target.name]: e.target.value }));

  // ── Place order ──────────────────────────────────────────────────────
  const handlePlaceOrder = async () => {
    setError('');
    setLoading(true);

    const shippingAddress = `${form.address}, ${form.city}`.trim().replace(/^,\s*/, '');

    const payload = {
      paymentMethod: paymentMethod.toUpperCase(),
      amount: total,
      userEmail: userData?.email || 'guest@velocity.com',
      userName: `${form.firstName} ${form.lastName}`.trim() || 'Khách hàng',
      shippingAddress: shippingAddress || '123 Performance Way, Portland',
      items: MOCK_CART_ITEMS.map((item) => ({
        name: item.name,
        quantity: item.qty,
        price: item.price,
        size: item.size,
        color: item.color,
      })),
    };

    try {
      const result = await paymentApi.initiate(payload);

      if (paymentMethod === 'vnpay' && result.paymentUrl) {
        // VNPay: redirect trình duyệt sang trang thanh toán
        window.location.href = result.paymentUrl;
        return;
      }

      // COD: hiển thị trang xác nhận
      setPlacedOrderId(result.orderId);
      setOrderPlaced(true);
    } catch (err) {
      setError('Đặt hàng thất bại: ' + err.message);
    } finally {
      setLoading(false);
    }
  };

  // ── Order confirmed screen ────────────────────────────────────────────
  if (orderPlaced) {
    return (
      <div className="flex flex-col min-h-screen bg-white">
        <Navbar />
        <main className="flex-1 flex items-center justify-center p-8">
          <div className="text-center max-w-lg">
            <div className="w-24 h-24 bg-green-50 text-green-500 rounded-full flex items-center justify-center mx-auto mb-8 animate-bounce">
              <span className="material-symbols-outlined text-5xl font-black">check</span>
            </div>
            <h1 className="text-4xl font-space-grotesk font-black text-zinc-900 mb-4 uppercase italic">
              Order Confirmed!
            </h1>
            <p className="text-zinc-500 mb-4 leading-relaxed">
              Đơn hàng{' '}
              <span className="text-zinc-900 font-bold">
                #{placedOrderId || 'VT-99281'}
              </span>{' '}
              đã được đặt thành công.
            </p>
            {form.email && (
              <p className="text-zinc-400 text-sm mb-10">
                📧 Email xác nhận đã được gửi đến{' '}
                <span className="font-semibold text-zinc-600">{form.email}</span>
              </p>
            )}
            <Link to="/explore">
              <button className="bg-zinc-900 text-white px-10 py-4 rounded-full font-bold hover:scale-105 transition-all shadow-xl">
                Continue Shopping
              </button>
            </Link>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  // ── Main checkout ─────────────────────────────────────────────────────
  return (
    <div className="flex flex-col min-h-screen bg-zinc-50/50">
      <Navbar />

      <main className="flex-1 pt-24 pb-20 px-margin-mobile md:px-margin-desktop max-w-[1200px] mx-auto w-full">
        {/* Stepper */}
        <div className="flex justify-center items-center gap-4 md:gap-8 mb-16">
          {[
            { n: 1, label: 'Shipping' },
            { n: 2, label: 'Payment' },
            { n: 3, label: 'Review' },
          ].map(({ n, label }, idx, arr) => (
            <React.Fragment key={n}>
              <div className={`flex items-center gap-3 transition-opacity ${step >= n ? 'opacity-100' : 'opacity-40'}`}>
                <span
                  className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-sm
                    ${step >= n ? 'bg-primary-container text-white' : 'bg-zinc-200 text-zinc-600'}`}
                >
                  {n}
                </span>
                <span className="text-zinc-900 font-bold text-sm">{label}</span>
              </div>
              {idx < arr.length - 1 && (
                <div className={`w-12 h-[2px] ${step > n ? 'bg-primary-container' : 'bg-zinc-200'}`} />
              )}
            </React.Fragment>
          ))}
        </div>

        <div className="flex flex-col lg:flex-row gap-12">
          {/* Main Content */}
          <div className="flex-1 space-y-10">

            {/* ── Step 1: Shipping ── */}
            {step === 1 && (
              <>
                <section className="bg-white rounded-[32px] p-8 md:p-10 shadow-[0_8px_30px_rgb(0,0,0,0.04)] animate-in fade-in slide-in-from-bottom-4 duration-500">
                  <div className="flex items-center gap-4 mb-8">
                    <div className="w-12 h-12 rounded-2xl bg-indigo-50 flex items-center justify-center text-primary-container">
                      <span className="material-symbols-outlined">local_shipping</span>
                    </div>
                    <h2 className="text-2xl font-bold text-zinc-900 uppercase tracking-tight">
                      Shipping Address
                    </h2>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <label className="text-xs font-black text-zinc-400 uppercase tracking-widest ml-1">
                        First Name
                      </label>
                      <input
                        type="text"
                        name="firstName"
                        value={form.firstName}
                        onChange={handleFormChange}
                        placeholder="John"
                        className="w-full bg-zinc-50 border-none rounded-2xl px-6 py-4 outline-none focus:ring-2 focus:ring-primary-container/20 transition-all"
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-xs font-black text-zinc-400 uppercase tracking-widest ml-1">
                        Last Name
                      </label>
                      <input
                        type="text"
                        name="lastName"
                        value={form.lastName}
                        onChange={handleFormChange}
                        placeholder="Doe"
                        className="w-full bg-zinc-50 border-none rounded-2xl px-6 py-4 outline-none focus:ring-2 focus:ring-primary-container/20 transition-all"
                      />
                    </div>
                    <div className="md:col-span-2 space-y-2">
                      <label className="text-xs font-black text-zinc-400 uppercase tracking-widest ml-1">
                        Street Address
                      </label>
                      <input
                        type="text"
                        name="address"
                        value={form.address}
                        onChange={handleFormChange}
                        placeholder="123 Performance Way"
                        className="w-full bg-zinc-50 border-none rounded-2xl px-6 py-4 outline-none focus:ring-2 focus:ring-primary-container/20 transition-all"
                      />
                    </div>
                    <div className="md:col-span-2 space-y-2">
                      <label className="text-xs font-black text-zinc-400 uppercase tracking-widest ml-1">
                        City
                      </label>
                      <input
                        type="text"
                        name="city"
                        value={form.city}
                        onChange={handleFormChange}
                        placeholder="Portland, Oregon"
                        className="w-full bg-zinc-50 border-none rounded-2xl px-6 py-4 outline-none focus:ring-2 focus:ring-primary-container/20 transition-all"
                      />
                    </div>
                  </div>
                </section>

                {/* Shipping Method */}
                <section className="bg-white rounded-[32px] p-8 md:p-10 shadow-[0_8px_30px_rgb(0,0,0,0.04)]">
                  <div className="flex items-center gap-4 mb-8">
                    <div className="w-12 h-12 rounded-2xl bg-blue-50 flex items-center justify-center text-blue-600">
                      <span className="material-symbols-outlined">package_2</span>
                    </div>
                    <h2 className="text-2xl font-bold text-zinc-900 uppercase tracking-tight">
                      Shipping Method
                    </h2>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {[
                      { value: 'standard', label: 'Standard', sub: '3–5 Business Days' },
                      { value: 'priority', label: 'Sonic Priority', sub: '1–2 Business Days' },
                    ].map(({ value, label, sub }) => (
                      <button
                        key={value}
                        onClick={() => setShippingMethod(value)}
                        className={`p-6 rounded-3xl border-2 transition-all flex flex-col items-start gap-4 text-left
                          ${shippingMethod === value
                            ? 'border-primary-container bg-primary-container/5'
                            : 'border-zinc-100 bg-white hover:border-zinc-200'}`}
                      >
                        <div className="flex justify-between w-full items-center">
                          <span className="font-bold text-zinc-900">{label}</span>
                          <div
                            className={`w-5 h-5 rounded-full border-2 flex items-center justify-center
                              ${shippingMethod === value
                                ? 'border-primary-container bg-primary-container'
                                : 'border-zinc-300'}`}
                          >
                            {shippingMethod === value && (
                              <div className="w-2 h-2 rounded-full bg-white" />
                            )}
                          </div>
                        </div>
                        <p className="text-xs text-zinc-500 font-bold uppercase">{sub}</p>
                      </button>
                    ))}
                  </div>
                </section>
              </>
            )}

            {/* ── Step 2: Payment ── */}
            {step === 2 && (
              <section className="bg-white rounded-[32px] p-8 md:p-10 shadow-[0_8px_30px_rgb(0,0,0,0.04)] animate-in fade-in slide-in-from-bottom-4 duration-500">
                <div className="flex items-center gap-4 mb-8">
                  <div className="w-12 h-12 rounded-2xl bg-purple-50 flex items-center justify-center text-purple-600">
                    <span className="material-symbols-outlined">payments</span>
                  </div>
                  <h2 className="text-2xl font-bold text-zinc-900 uppercase tracking-tight">
                    Select Payment
                  </h2>
                </div>
                <div className="space-y-4">
                  {/* COD */}
                  <button
                    onClick={() => setPaymentMethod('cod')}
                    className={`w-full p-6 rounded-3xl border-2 transition-all flex items-center gap-6 text-left
                      ${paymentMethod === 'cod'
                        ? 'border-primary-container bg-primary-container/5'
                        : 'border-zinc-100 bg-white hover:border-zinc-200'}`}
                  >
                    <div
                      className={`w-12 h-12 rounded-2xl flex items-center justify-center
                        ${paymentMethod === 'cod' ? 'bg-primary-container text-white' : 'bg-zinc-50 text-zinc-400'}`}
                    >
                      <span className="material-symbols-outlined">payments</span>
                    </div>
                    <div className="flex-1">
                      <p className="font-bold text-zinc-900">Thanh toán khi nhận hàng (COD)</p>
                      <p className="text-xs text-zinc-500 text-balance">
                        Thanh toán bằng tiền mặt khi shipper giao hàng đến địa chỉ của bạn.
                      </p>
                    </div>
                    <div
                      className={`w-5 h-5 rounded-full border-2 flex items-center justify-center shrink-0
                        ${paymentMethod === 'cod'
                          ? 'border-primary-container bg-primary-container'
                          : 'border-zinc-300'}`}
                    >
                      {paymentMethod === 'cod' && <div className="w-2 h-2 rounded-full bg-white" />}
                    </div>
                  </button>

                  {/* VNPay */}
                  <button
                    onClick={() => setPaymentMethod('vnpay')}
                    className={`w-full p-6 rounded-3xl border-2 transition-all flex items-center gap-6 text-left
                      ${paymentMethod === 'vnpay'
                        ? 'border-primary-container bg-primary-container/5'
                        : 'border-zinc-100 bg-white hover:border-zinc-200'}`}
                  >
                    <div className="w-12 h-12 rounded-2xl flex items-center justify-center bg-white p-2 border border-zinc-100">
                      <img
                        src="https://sandbox.vnpayment.vn/paymentv2/Images/brands/logo.svg"
                        alt="VNPay"
                        className="w-full h-full object-contain"
                      />
                    </div>
                    <div className="flex-1">
                      <p className="font-bold text-zinc-900">Ví điện tử VNPay</p>
                      <p className="text-xs text-zinc-500 text-balance">
                        Thanh toán nhanh chóng, an toàn qua ứng dụng ngân hàng hoặc ví VNPay.
                      </p>
                    </div>
                    <div
                      className={`w-5 h-5 rounded-full border-2 flex items-center justify-center shrink-0
                        ${paymentMethod === 'vnpay'
                          ? 'border-primary-container bg-primary-container'
                          : 'border-zinc-300'}`}
                    >
                      {paymentMethod === 'vnpay' && <div className="w-2 h-2 rounded-full bg-white" />}
                    </div>
                  </button>
                </div>
              </section>
            )}

            {/* ── Step 3: Review ── */}
            {step === 3 && (
              <section className="bg-white rounded-[32px] p-8 md:p-10 shadow-[0_8px_30px_rgb(0,0,0,0.04)] animate-in fade-in slide-in-from-bottom-4 duration-500">
                <div className="flex items-center gap-4 mb-8">
                  <div className="w-12 h-12 rounded-2xl bg-orange-50 flex items-center justify-center text-orange-600">
                    <span className="material-symbols-outlined">fact_check</span>
                  </div>
                  <h2 className="text-2xl font-bold text-zinc-900 uppercase tracking-tight">
                    Review Order
                  </h2>
                </div>
                <div className="space-y-8">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                    <div className="p-6 bg-zinc-50 rounded-2xl">
                      <p className="text-[10px] font-black text-zinc-400 uppercase tracking-widest mb-3">
                        Shipping to
                      </p>
                      <p className="font-bold text-zinc-900">
                        {`${form.firstName} ${form.lastName}`.trim() || userData?.fullName || 'John Doe'}
                      </p>
                      <p className="text-sm text-zinc-500">
                        {form.address || '123 Performance Way'}{form.city ? `, ${form.city}` : ''}
                      </p>
                      {userData?.email && (
                        <p className="text-sm text-zinc-400 mt-1">{userData.email}</p>
                      )}
                    </div>
                    <div className="p-6 bg-zinc-50 rounded-2xl">
                      <p className="text-[10px] font-black text-zinc-400 uppercase tracking-widest mb-3">
                        Payment via
                      </p>
                      <p className="font-bold text-zinc-900">
                        {paymentMethod === 'cod' ? 'Cash on Delivery' : 'VNPay Wallet'}
                      </p>
                      <p className="text-sm text-zinc-500">
                        {shippingMethod === 'standard'
                          ? 'Standard Delivery (3-5 Days)'
                          : 'Sonic Priority (1-2 Days)'}
                      </p>
                    </div>
                  </div>

                  {/* Items */}
                  <div className="p-6 border border-zinc-100 rounded-2xl">
                    <p className="text-[10px] font-black text-zinc-400 uppercase tracking-widest mb-4">
                      Items Summary
                    </p>
                    <div className="space-y-4">
                      {MOCK_CART_ITEMS.map((item) => (
                        <div key={item.id} className="flex justify-between items-center text-sm">
                          <span className="text-zinc-600">
                            {item.name}{' '}
                            <span className="text-zinc-400">x{item.qty}</span>
                          </span>
                          <span className="font-bold text-zinc-900">
                            ${(item.price * item.qty).toFixed(2)}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Error message */}
                  {error && (
                    <div className="p-4 bg-red-50 border border-red-100 rounded-2xl text-red-600 text-sm font-medium">
                      {error}
                    </div>
                  )}
                </div>
              </section>
            )}

            {/* Navigation Buttons */}
            <div className="flex justify-between items-center pt-6">
              {step > 1 ? (
                <button
                  onClick={() => setStep(step - 1)}
                  className="flex items-center gap-2 text-zinc-500 font-bold hover:text-zinc-900 transition-colors"
                >
                  <span className="material-symbols-outlined">arrow_back</span>
                  Back
                </button>
              ) : (
                <Link
                  to="/cart"
                  className="flex items-center gap-2 text-zinc-500 font-bold hover:text-zinc-900 transition-colors"
                >
                  <span className="material-symbols-outlined">arrow_back</span>
                  Back to Cart
                </Link>
              )}

              {step < 3 ? (
                <button
                  onClick={() => setStep(step + 1)}
                  className="bg-primary-container text-white px-10 py-4 rounded-2xl font-bold shadow-xl hover:scale-105 active:scale-95 transition-all flex items-center gap-3"
                >
                  Continue
                  <span className="material-symbols-outlined">arrow_forward</span>
                </button>
              ) : (
                <button
                  onClick={handlePlaceOrder}
                  disabled={loading}
                  className="bg-primary-container text-white px-10 py-4 rounded-2xl font-bold shadow-xl hover:scale-105 active:scale-95 transition-all flex items-center gap-3 disabled:opacity-60 disabled:cursor-not-allowed disabled:hover:scale-100"
                >
                  {loading ? (
                    <>
                      <span className="animate-spin material-symbols-outlined">progress_activity</span>
                      {paymentMethod === 'vnpay' ? 'Đang chuyển hướng...' : 'Đang xử lý...'}
                    </>
                  ) : (
                    <>
                      {paymentMethod === 'vnpay' ? 'Thanh toán với VNPay' : 'Place Order'}
                      <span className="material-symbols-outlined">arrow_forward</span>
                    </>
                  )}
                </button>
              )}
            </div>
          </div>

          {/* Sidebar Summary */}
          <div className="lg:w-[380px]">
            <div className="bg-white rounded-[32px] p-8 md:p-10 shadow-[0_20px_50px_rgba(0,0,0,0.06)] sticky top-28">
              <h2 className="text-xl font-bold mb-8 uppercase tracking-tight">Order Summary</h2>

              <div className="space-y-6 mb-8">
                {MOCK_CART_ITEMS.map((item) => (
                  <div key={item.id} className="flex gap-4 items-center">
                    <div className="w-16 h-16 bg-zinc-50 rounded-2xl p-2 flex items-center justify-center shrink-0">
                      <img src={item.image} alt={item.name} className="w-full h-full object-contain" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-bold text-sm text-zinc-900 truncate">{item.name}</p>
                      <p className="text-[10px] text-zinc-400 font-bold uppercase tracking-widest">
                        Qty: {item.qty} | {item.size}
                      </p>
                    </div>
                    <p className="font-bold text-sm text-zinc-900">
                      ${(item.price * item.qty).toFixed(2)}
                    </p>
                  </div>
                ))}
              </div>

              <div className="space-y-4 pt-6 border-t border-zinc-100 mb-8">
                <div className="flex justify-between text-sm">
                  <span className="text-zinc-500">Subtotal</span>
                  <span className="font-bold text-zinc-900">${subtotal.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-zinc-500">Shipping</span>
                  <span className="font-black text-primary-container uppercase text-xs">Free</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-zinc-500">Estimated Tax</span>
                  <span className="font-bold text-zinc-900">${tax.toFixed(2)}</span>
                </div>
              </div>

              <div className="flex justify-between items-end mb-10">
                <span className="text-2xl font-black font-space-grotesk italic">Total</span>
                <span className="text-3xl font-black text-primary-container font-space-grotesk italic">
                  ${total.toFixed(2)}
                </span>
              </div>

              <div className="mt-6 flex items-center justify-center gap-2 text-zinc-400">
                <span className="material-symbols-outlined text-sm">lock</span>
                <span className="text-[10px] font-bold uppercase tracking-widest">
                  SSL Encrypted Checkout
                </span>
              </div>
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
};

export default CheckoutPage;