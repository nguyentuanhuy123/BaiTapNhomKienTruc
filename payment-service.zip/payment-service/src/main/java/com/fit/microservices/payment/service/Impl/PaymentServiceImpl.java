package com.fit.microservices.payment.service.Impl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fit.microservices.payment.dto.PaymentRequest;
import com.fit.microservices.payment.dto.PaymentResponse;
import com.fit.microservices.payment.event.InventoryReservedEvent;
import com.fit.microservices.payment.event.PaymentCompletedEvent;
import com.fit.microservices.payment.model.Payment;
import com.fit.microservices.payment.model.PaymentMethod;
import com.fit.microservices.payment.model.PaymentStatus;
import com.fit.microservices.payment.producer.KafkaProducerService;
import com.fit.microservices.payment.repository.PaymentRepository;
import com.fit.microservices.payment.service.PaymentService;
import com.fit.microservices.payment.service.gateway.PaymentGateway;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicLong;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class PaymentServiceImpl implements PaymentService {

    private final PaymentRepository paymentRepository;
    private final PaymentGateway paymentGateway;
    private final KafkaProducerService kafkaProducerService;
    private final ObjectMapper objectMapper;

    // Mock order ID generator
    private static final AtomicLong orderIdGen = new AtomicLong(10000);

    // ── Kafka flow (inventory reserved) ────────────────────────────────
    @Override
    @Transactional
    public PaymentResponse processPayment(InventoryReservedEvent event) {
        if (!"RESERVED".equalsIgnoreCase(event.getStatus())) {
            return null;
        }

        Payment payment = paymentRepository
                .findByOrderId(event.getOrderId())
                .orElseGet(() -> {
                    Payment p = new Payment();
                    p.setOrderId(event.getOrderId());
                    p.setAmount(BigDecimal.valueOf(100));
                    p.setMethod(PaymentMethod.VNPAY);
                    p.setStatus(PaymentStatus.PENDING);
                    p.setTransactionId(UUID.randomUUID().toString());
                    return paymentRepository.save(p);
                });

        if (payment.getStatus() != PaymentStatus.PENDING) {
            return new PaymentResponse(payment.getOrderId(), payment.getStatus().name(),
                    payment.getPaymentUrl(), "Already processed");
        }

        if (payment.getPaymentUrl() == null) {
            String paymentUrl = paymentGateway.createPaymentUrl(payment);
            payment.setPaymentUrl(paymentUrl);
            paymentRepository.save(payment);
        }

        return new PaymentResponse(payment.getOrderId(), payment.getStatus().name(),
                payment.getPaymentUrl(), null);
    }

    // ── REST flow từ Checkout FE ────────────────────────────────────────
    @Override
    @Transactional
    public PaymentResponse initiatePayment(PaymentRequest request) {
        long orderId = orderIdGen.incrementAndGet();

        Payment payment = new Payment();
        payment.setOrderId(orderId);
        payment.setAmount(request.getAmount() != null ? request.getAmount() : BigDecimal.ZERO);
        payment.setTransactionId(UUID.randomUUID().toString());
        payment.setUserEmail(request.getUserEmail());
        payment.setUserName(request.getUserName());
        payment.setShippingAddress(request.getShippingAddress());

        // Serialize items thành JSON để lưu DB
        if (request.getItems() != null) {
            try {
                payment.setItemsJson(objectMapper.writeValueAsString(request.getItems()));
            } catch (JsonProcessingException e) {
                payment.setItemsJson("[]");
            }
        }

        // ── COD: SUCCESS ngay, gửi Kafka → email ──
        if ("COD".equalsIgnoreCase(request.getPaymentMethod())) {
            payment.setMethod(PaymentMethod.COD);
            payment.setStatus(PaymentStatus.SUCCESS);
            paymentRepository.save(payment);

            kafkaProducerService.sendPaymentCompleted(buildCompletedEvent(payment, request));

            return new PaymentResponse(orderId, "SUCCESS", null, "Đặt hàng thành công!");
        }

        // ── VNPay: tạo URL, trả về FE để redirect ──
        payment.setMethod(PaymentMethod.VNPAY);
        payment.setStatus(PaymentStatus.PENDING);
        paymentRepository.save(payment);

        String paymentUrl = paymentGateway.createPaymentUrl(payment);
        payment.setPaymentUrl(paymentUrl);
        paymentRepository.save(payment);

        return new PaymentResponse(orderId, "PENDING", paymentUrl, null);
    }

    // ── Helper: build PaymentCompletedEvent đầy đủ thông tin ──────────
    private PaymentCompletedEvent buildCompletedEvent(Payment payment, PaymentRequest request) {
        List<PaymentCompletedEvent.OrderItem> items = null;

        if (request.getItems() != null) {
            items = request.getItems().stream()
                    .map(i -> new PaymentCompletedEvent.OrderItem(
                            i.getName(),
                            i.getQuantity(),
                            i.getPrice() != null ? i.getPrice().doubleValue() : 0.0,
                            i.getSize(),
                            i.getColor()
                    ))
                    .collect(Collectors.toList());
        }

        return new PaymentCompletedEvent(
                payment.getOrderId(),
                payment.getTransactionId(),
                payment.getAmount().doubleValue(),
                payment.getMethod().name(),
                payment.getUserEmail(),
                payment.getUserName(),
                payment.getShippingAddress(),
                items
        );
    }
}
