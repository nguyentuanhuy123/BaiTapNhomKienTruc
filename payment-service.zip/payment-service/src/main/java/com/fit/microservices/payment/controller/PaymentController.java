package com.fit.microservices.payment.controller;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fit.microservices.payment.event.PaymentCompletedEvent;
import com.fit.microservices.payment.event.PaymentFailedEvent;
import com.fit.microservices.payment.model.Payment;
import com.fit.microservices.payment.model.PaymentStatus;
import com.fit.microservices.payment.producer.KafkaProducerService;
import com.fit.microservices.payment.repository.PaymentRepository;
import com.fit.microservices.payment.service.gateway.PaymentGateway;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/payment/callback")
@RequiredArgsConstructor
public class PaymentController {

    private final PaymentRepository paymentRepository;
    private final KafkaProducerService kafkaProducerService;
    private final PaymentGateway paymentGateway;
    private final ObjectMapper objectMapper;

    /** URL trang FE hiển thị kết quả sau khi VNPay redirect về */
    @Value("${payment.fe.returnUrl:http://localhost:5173/payment/return}")
    private String feReturnUrl;

    @GetMapping("/vnpay")
    public ResponseEntity<Void> callback(@RequestParam Map<String, String> params) {

        String txnRef = params.get("vnp_TxnRef");
        String responseCode = params.get("vnp_ResponseCode");

        Payment payment = paymentRepository
                .findByTransactionId(txnRef)
                .orElse(null);

        if (payment == null) {
            return ResponseEntity.status(HttpStatus.FOUND)
                    .location(URI.create(feReturnUrl + "?status=failed&reason=not_found"))
                    .build();
        }

        // Idempotent – nếu đã xử lý thì redirect luôn
        if (payment.getStatus() != PaymentStatus.PENDING) {
            String status = payment.getStatus() == PaymentStatus.SUCCESS ? "success" : "failed";
            return ResponseEntity.status(HttpStatus.FOUND)
                    .location(URI.create(feReturnUrl + "?status=" + status
                            + "&orderId=" + payment.getOrderId()))
                    .build();
        }

        if ("00".equals(responseCode)) {
            payment.setStatus(PaymentStatus.SUCCESS);
            payment.setGatewayTransactionId(params.get("vnp_TransactionNo"));
            paymentRepository.save(payment);

            // Build event đầy đủ thông tin để notification service gửi email
            kafkaProducerService.sendPaymentCompleted(buildCompletedEvent(payment));

            return ResponseEntity.status(HttpStatus.FOUND)
                    .location(URI.create(feReturnUrl
                            + "?status=success"
                            + "&orderId=" + payment.getOrderId()
                            + "&amount=" + payment.getAmount()))
                    .build();

        } else {
            payment.setStatus(PaymentStatus.FAILED);
            paymentRepository.save(payment);

            kafkaProducerService.sendPaymentFailed(
                    new PaymentFailedEvent(payment.getOrderId(), "VNPay failed: " + responseCode)
            );

            return ResponseEntity.status(HttpStatus.FOUND)
                    .location(URI.create(feReturnUrl
                            + "?status=failed"
                            + "&orderId=" + payment.getOrderId()
                            + "&reason=" + responseCode))
                    .build();
        }
    }

    private PaymentCompletedEvent buildCompletedEvent(Payment payment) {
        List<PaymentCompletedEvent.OrderItem> items = null;

        if (payment.getItemsJson() != null && !payment.getItemsJson().isBlank()) {
            try {
                List<Map<String, Object>> rawItems = objectMapper.readValue(
                        payment.getItemsJson(),
                        new TypeReference<>() {}
                );
                items = rawItems.stream().map(m -> {
                    PaymentCompletedEvent.OrderItem item = new PaymentCompletedEvent.OrderItem();
                    item.setName((String) m.getOrDefault("name", ""));
                    item.setQuantity(((Number) m.getOrDefault("quantity", 1)).intValue());
                    item.setPrice(((Number) m.getOrDefault("price", 0)).doubleValue());
                    item.setSize((String) m.getOrDefault("size", ""));
                    item.setColor((String) m.getOrDefault("color", ""));
                    return item;
                }).collect(Collectors.toList());
            } catch (Exception ignored) {}
        }

        return new PaymentCompletedEvent(
                payment.getOrderId(),
                payment.getTransactionId(),
                payment.getAmount().doubleValue(),
                payment.getMethod().name(),
                payment.getUserEmail(),
                payment.getUserName(),
                payment.getShippingAddress(),
                items
        );
    }
}
